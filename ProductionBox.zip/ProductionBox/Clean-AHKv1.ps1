Write-Host "Cleaning AutoHotkey v1..." -ForegroundColor Cyan

# -----------------------------------------------------
# 1. Delete common AutoHotkey installation folders
# -----------------------------------------------------
$paths = @(
    "C:\Program Files\AutoHotkey",
    "C:\Program Files (x86)\AutoHotkey",
    "$env:LOCALAPPDATA\AutoHotkey",
    "$env:APPDATA\AutoHotkey"
)

foreach ($p in $paths) {
    if (Test-Path $p) {
        Write-Host "Deleting folder: $p"
        Remove-Item -Path $p -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# -----------------------------------------------------
# 2. Remove AutoHotkey.exe left anywhere else
# -----------------------------------------------------
Write-Host "Searching for stray AutoHotkey executables..."

$matches = Get-ChildItem -Path "C:\" -Recurse -Filter "AutoHotkey*.exe" -ErrorAction SilentlyContinue

foreach ($m in $matches) {
    Write-Host "Deleting: $($m.FullName)"
    Remove-Item "$($m.FullName)" -Force -ErrorAction SilentlyContinue
}

# -----------------------------------------------------
# 3. Remove Registry Entries
# -----------------------------------------------------
$regKeys = @(
    "HKCU:\Software\AutoHotkey",
    "HKLM:\SOFTWARE\AutoHotkey",
    "HKCR:\AutoHotkeyScript",
    "HKCR:\.ahk"
)

foreach ($rk in $regKeys) {
    if (Test-Path $rk) {
        Write-Host "Removing Registry Key: $rk"
        Remove-Item $rk -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# -----------------------------------------------------
# 4. Remove file association for .ahk
# -----------------------------------------------------
Write-Host "Resetting .ahk file association..."
cmd /c assoc .ahk=
cmd /c ftype AutoHotkeyScript=

Write-Host "Cleanup Completed Successfully!" -ForegroundColor Green
Pause
